// Copyright 2010 Google Inc. All Rights Reserved.
// Author: sligocki@google.com (Shawn Ligocki)

#ifndef WEBUTIL_CSS_OPEN_SOURCE_STRING_USING_H_
#define WEBUTIL_CSS_OPEN_SOURCE_STRING_USING_H_

using std::string;

#endif  // WEBUTIL_CSS_OPEN_SOURCE_STRING_USING_H_
